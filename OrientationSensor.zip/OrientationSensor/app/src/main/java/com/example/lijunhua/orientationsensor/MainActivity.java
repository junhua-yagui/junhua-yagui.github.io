package com.example.lijunhua.orientationsensor;

import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.animation.Animation;
import android.view.animation.RotateAnimation;
import android.widget.ImageView;

public class MainActivity extends AppCompatActivity {

    private SensorManager sensorManager;

    private ImageView needleimg;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        needleimg = (ImageView) findViewById(R.id.needleimg);

        sensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);//获取sensorManager
        Sensor magneticSensor = sensorManager.getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD);//获取方向传感器
        Sensor accelerometerSensor = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);//获取加速度传感器
        sensorManager.registerListener(listener,magneticSensor,SensorManager.SENSOR_DELAY_GAME);//SENSOR_DELAY_GAME,高灵敏度
        sensorManager.registerListener(listener,accelerometerSensor,SensorManager.SENSOR_DELAY_GAME);
    }

    @Override
    protected  void onDestroy()
    {
        super.onDestroy();
        if(sensorManager!=null)
        {
            sensorManager.unregisterListener(listener);
        }
    }

    private SensorEventListener listener = new SensorEventListener() {

        float[] accelerometerValues =  new float[3];

        float[] magneticValues = new float[3];

        private  float lastRotateDegree;

        @Override
        public void onSensorChanged(SensorEvent event) {
            if(event.sensor.getType() == Sensor.TYPE_ACCELEROMETER)
            {
                accelerometerValues = event.values.clone();
            }
            else if(event.sensor.getType() == Sensor.TYPE_MAGNETIC_FIELD)
            {
                magneticValues = event.values.clone();
            }
            float[] R = new float[9];
            float[] values = new float[3];
            SensorManager.getRotationMatrix(R,null,accelerometerValues,magneticValues);
            SensorManager.getOrientation(R,values);

            float rotateDegree = -(float) Math.toDegrees(values[0]);
            if(Math.abs(rotateDegree-lastRotateDegree)>1)
            {
                RotateAnimation animation = new RotateAnimation(lastRotateDegree
                 ,rotateDegree, Animation.RELATIVE_TO_SELF,0.5f
                 ,Animation.RELATIVE_TO_SELF,0.5f);//开始的旋转角度，结束的旋转角度,x的伸缩模式，x的伸缩值，y的伸缩模式，y的伸缩值
                animation.setFillAfter(true);//If fillAfter is true, the transformation that this animation performed will persist when it is finished.
                needleimg.startAnimation(animation);
                lastRotateDegree = rotateDegree;
            }
        }

        @Override
        public void onAccuracyChanged(Sensor sensor, int accuracy) {

        }
    };
}
