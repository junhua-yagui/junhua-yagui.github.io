package com.example.lijunhua.test;

import android.os.SystemClock;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class MainActivity extends AppCompatActivity {

    ImageView imageView;
    ImageView imageViewtwo;
    ImageView imageViewthree;
    TextView textView;
    Button button;
    private StringBuilder respond;
    private String string = null;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        imageView = findViewById(R.id.imageview);
        imageViewtwo = findViewById(R.id.imageviewtwo);
        imageViewthree = findViewById(R.id.imageviewthree);
        textView = findViewById(R.id.textview);

        button = findViewById(R.id.btnone);

       button.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View v) {
               try {
                   for(int i=1;i<=3;i++)
                   {
                       connectToCat();
                       parseJSONWithJSONobject(respond.toString(),i);
                   }
               } catch (Exception e) {
                   e.printStackTrace();
               }
           }
       });
    }

    public void connectToCat() throws InterruptedException {
        Thread thread=new Thread(new Runnable()
        {
            @Override
            public void run()
            {
                HttpURLConnection httpURLConnection = null;
                BufferedReader reader = null;
                try {
                    URL url = new URL("https://api.thecatapi.com/v1/images/search?format=json");
                    httpURLConnection = (HttpURLConnection) url.openConnection();
                    httpURLConnection.setConnectTimeout(5000);
                    httpURLConnection.setReadTimeout(5000);
                    httpURLConnection.setRequestMethod("GET");
                    InputStream inputStream = httpURLConnection.getInputStream();
                    reader = new BufferedReader(new InputStreamReader(inputStream));
                    respond = new StringBuilder();
                    while((string = reader.readLine())!= null)
                    {
                        respond.append(string);
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
                finally {
                    try {
                        if(reader!= null)
                        {
                            reader.close();
                        }
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                    if (httpURLConnection!= null) {
                        httpURLConnection.disconnect();
                    }
                }
            }
        });
        thread.start();
        thread.join();
    }

    private  void parseJSONWithJSONobject(final String jsonData,int i)
    {
        switch (i)
        {
            case 1:
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        try{
                            JSONArray jsonArray = new JSONArray(jsonData);
                            for(int i=0;i<jsonArray.length();i++)
                            {
                                JSONObject jsonObject = jsonArray.getJSONObject(i);
                                String url = jsonObject.getString("url");
                                textView.setText(url);
                                Glide.with(MainActivity.this).load(url).into(imageView);
                            }
                        }catch (Exception e)
                        {
                            e.printStackTrace();
                        }
                    }
                });
                break;
            case 2:
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        try{
                            JSONArray jsonArray = new JSONArray(jsonData);
                            for(int i=0;i<jsonArray.length();i++)
                            {
                                JSONObject jsonObject = jsonArray.getJSONObject(i);
                                String url = jsonObject.getString("url");
                                Glide.with(MainActivity.this).load(url).into(imageViewtwo);
                            }
                        }catch (Exception e)
                        {
                            e.printStackTrace();
                        }
                    }
                });
                break;
            case 3:
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        try{
                            JSONArray jsonArray = new JSONArray(jsonData);
                            for(int i=0;i<jsonArray.length();i++)
                            {
                                JSONObject jsonObject = jsonArray.getJSONObject(i);
                                String url = jsonObject.getString("url");
                                textView.setText(url);
                                Glide.with(MainActivity.this).load(url).into(imageViewthree);
                            }
                        }catch (Exception e)
                        {
                            e.printStackTrace();
                        }
                    }
                });
                break;
        }

    }

//    private void show(final String str )
//    {
//        runOnUiThread(new Runnable() {
//            @Override
//            public void run() {
//                textView.setText(str);
//            }
//        });
//    }


}
