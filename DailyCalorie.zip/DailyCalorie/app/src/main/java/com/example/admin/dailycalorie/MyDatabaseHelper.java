package com.example.admin.dailycalorie;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import java.sql.SQLData;

public class MyDatabaseHelper extends SQLiteOpenHelper {

    private static final String DBName ="Carlorie.db";
    private static final String CREATE_CALORIE_TABLE
          = "CREATE TABLE Powerthree (id INTEGER PRIMARY KEY AUTOINCREMENT,year INTEGER,month INTEGER,day INTEGER,power TEXT)";

    public MyDatabaseHelper(Context context, int version) {
        super(context, DBName, null, version);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        sqLiteDatabase.execSQL(CREATE_CALORIE_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        sqLiteDatabase.execSQL(CREATE_CALORIE_TABLE);
    }
}
