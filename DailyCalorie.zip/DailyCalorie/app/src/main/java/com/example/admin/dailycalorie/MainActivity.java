package com.example.admin.dailycalorie;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;

import com.jjoe64.graphview.GraphView;
import com.jjoe64.graphview.helper.StaticLabelsFormatter;
import com.jjoe64.graphview.series.DataPoint;
import com.jjoe64.graphview.series.LineGraphSeries;

public class MainActivity extends AppCompatActivity {

        SQLiteDatabase db;
        String year="",month="",day="",yeartwo="",monthtwo="",daytwo="";
        String textone,texttwo;
        String newdayone = "",newdaytwo="",newmonthone="",newmonthtwo="",newyearone="",newyeartwo="";
         GraphView graph;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button editbtn = (Button) findViewById(R.id.editbtn);
        editbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, Main2Activity.class);
                startActivity(intent);
            }
        });

        Button datebtnone = (Button)findViewById(R.id.datebtnone);
        textone = datebtnone.getText().toString();
        Button datebtntwo = (Button)findViewById(R.id.datebtntwo);
        texttwo = datebtntwo.getText().toString();

        //get the date
        Intent intentthis = getIntent();
        year = intentthis.getStringExtra("year");
        month = intentthis.getStringExtra("month");
        day = intentthis.getStringExtra("day");
        if(day!=null)
            datebtnone.setText(year + "-" + month + "-" + day);
        yeartwo = intentthis.getStringExtra("yeartwo");
        monthtwo = intentthis.getStringExtra("monthtwo");
        daytwo = intentthis.getStringExtra("daytwo");
        if(yeartwo!=null)
            datebtntwo.setText(yeartwo + "-" + monthtwo + "-" + daytwo);


        datebtnone.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this,Main4Activity.class);
                //send the date
                intent.putExtra("year",year);
                intent.putExtra("month",month);
                intent.putExtra("day",day);
                intent.putExtra("yeartwo",yeartwo);
                intent.putExtra("monthtwo",monthtwo);
                intent.putExtra("daytwo",daytwo);
                startActivity(intent);
            }
        });

        datebtntwo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this,Main5Activity.class);
                //send the date
                intent.putExtra("year",year);
                intent.putExtra("month",month);
                intent.putExtra("day",day);
                intent.putExtra("yeartwo",yeartwo);
                intent.putExtra("monthtwo",monthtwo);
                intent.putExtra("daytwo",daytwo);
                startActivity(intent);
            }
        });

        //cout the horizontaoLables
        if(day!=null) {
            newdayone = (Integer.parseInt(day) + 5) + "";
            newmonthone = (Integer.parseInt(month) + 1) + "";
            newyearone = (Integer.parseInt(year)-2000)+"";
        }
        if(daytwo!=null) {
            newdaytwo = (Integer.parseInt(day) + 5) + "";
            newmonthtwo = (Integer.parseInt(monthtwo) + 1) + "";
            newyeartwo = (Integer.parseInt(yeartwo)-2000)+"";
        }
        if(year!=null && yeartwo!=null) {
            graph = findViewById(R.id.graph);
            StaticLabelsFormatter staticLabelsFormatter = new StaticLabelsFormatter(graph);
            staticLabelsFormatter.setVerticalLabels(new String[]{"0.5", "0.75", "1", "1.25", "1.5"});
            staticLabelsFormatter.setHorizontalLabels(new String[]{day + "/" + month + "/" + (Integer.parseInt(year) - 2000), newdayone + "/" + newmonthone + "/"
                    + newyearone, newdaytwo + "/" + newmonthtwo + "/" + newyeartwo, daytwo + "/" + monthtwo + "/" + (Integer.parseInt(yeartwo) - 2000)});
            graph.getGridLabelRenderer().setLabelFormatter(staticLabelsFormatter);

        }

        //draw the line
       Button querybtn =(Button)findViewById(R.id.query);
        querybtn.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View v) {
               graph.removeAllSeries();
               getpowerAnddraw(graph);
          }
       });
    }

    public void getpowerAnddraw(GraphView graph)
    {
        Double[] num = new Double[5];
        int counter=0;
       double powerers=0;
       int yearget=0;
       double position=0.1;
       int years=0,yeartwos=0;
           years = Integer.parseInt(year);
          yeartwos = Integer.parseInt(yeartwo);

          //Initiate
        for(int i=0;i<=4;i++)
        {
            num[i]=0.0;
        }

        db = Main3Activity.getDB();
        Cursor cursor = db.query("Powerthree",null,null,null,null,null,null);
        if(cursor.moveToFirst()) {
            do {
                    yearget = Integer.parseInt(cursor.getString(cursor.getColumnIndex("year")));
                    if(yearget>=years && yearget<=yeartwos) {
                        powerers = Integer.parseInt(cursor.getString(cursor.getColumnIndex("power"))) / (double) 10000.0;
                        num[counter]=powerers;
                        counter++;
                    }
           } while (cursor.moveToNext());
        }
        LineGraphSeries<DataPoint> series = new LineGraphSeries<>();
        DataPoint dp = new DataPoint(0,0);
        series.appendData(dp,true,100,true);
        for(int i=0;i<=counter;i++)
        {
            DataPoint dp1 = new DataPoint(position,num[i]);
            series.appendData(dp1,true,100,true);
            position+=0.05;
        }
        graph.addSeries(series);
        cursor.close();
    }

}
