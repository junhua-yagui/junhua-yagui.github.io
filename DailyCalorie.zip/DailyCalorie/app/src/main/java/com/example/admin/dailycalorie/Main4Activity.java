package com.example.admin.dailycalorie;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;

public class Main4Activity extends AppCompatActivity {

    private int day,month,year;
    String daytwo,monthtwo,yeartwo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main4);

        Button cancel = (Button)findViewById(R.id.cancelbtntwo);
        Button ok = (Button)findViewById(R.id.okbtntwo);

        cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        ok.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DatePicker dp =  findViewById(R.id.datethree);
                day = dp.getDayOfMonth();
                month = dp.getMonth();
                year = dp.getYear();
                Intent intents = getIntent();
                daytwo = intents.getStringExtra("daytwo");
                monthtwo = intents.getStringExtra("monthtwo");
                yeartwo = intents.getStringExtra("yeartwo");
                Intent intent = new Intent(Main4Activity.this,MainActivity.class);
                intent.putExtra("year",Integer.toString(year));
                intent.putExtra("month",Integer.toString(month));
                intent.putExtra("day",Integer.toString(day));
                intent.putExtra("yeartwo",yeartwo);
                intent.putExtra("daytwo",daytwo);
                intent.putExtra("monthtwo",monthtwo);
                startActivity(intent);
            }
        });
    }
}
