package com.example.admin.dailycalorie;

import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class Main2Activity extends AppCompatActivity{

    SQLiteDatabase db;
    String year;
    String month;
    String day;
    String calpower;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        Button addbtn = (Button) findViewById(R.id.add);
        addbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Main2Activity.this, Main3Activity.class);
                startActivity(intent);
            }
        });
        Button reflashbtn = (Button) findViewById(R.id.reflash);
        reflashbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                queryDate();
            }
        });

        Button delone = (Button)findViewById(R.id.delone);
        Button deltwo = (Button)findViewById(R.id.deltwo);
        Button delthree = (Button)findViewById(R.id.delthree);
        Button delfour = (Button)findViewById(R.id.delfour);
        Button delfive  = (Button)findViewById(R.id.delfive);

        delone.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EditText edone = findViewById(R.id.txtone);
                edone.setText("");
                GetDeleteId();
            }
        });
        deltwo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                EditText edtwo = findViewById(R.id.txttwo);
                edtwo.setText("");
                GetDeleteId();
            }
        });
        delthree.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                EditText edthree = findViewById(R.id.txtthree);
                edthree.setText("");
                GetDeleteId();
            }
        });
        delfour.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                EditText edfour = findViewById(R.id.txtfour);
                edfour.setText("");
                GetDeleteId();
            }
        });
        delfive.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EditText edfive = findViewById(R.id.txtfive);
                edfive.setText("");
                GetDeleteId();
            }
        });
    }

    public void queryDate()
    {
        EditText ed1 = findViewById(R.id.txtone);
        EditText ed2 = findViewById(R.id.txttwo);
        EditText ed3 = findViewById(R.id.txtthree);
        EditText ed4 = findViewById(R.id.txtfour);
        EditText ed5 = findViewById(R.id.txtfive);
        ed1.setText("");
        ed2.setText("");
        ed3.setText("");
        ed4.setText("");
        ed5.setText("");
        db = Main3Activity.getDB();
        Cursor cursor = db.query("Powerthree",null,null,null,null,null,null);
        if(cursor.moveToFirst()) {
            do {
                year = cursor.getString(cursor.getColumnIndex("year"));
                month = cursor.getString(cursor.getColumnIndex("month"));
                day = cursor.getString(cursor.getColumnIndex("day"));
                calpower = cursor.getString(cursor.getColumnIndex("power"));
                InitiateEdittext();
            } while (cursor.moveToNext());
        }
        cursor.close();
    }

    public void deleteDate(int id)
    {
        db.delete("Powerthree","id=?",new String[]{Integer.toString(id)});
    }

    public void InitiateEdittext() {
        EditText ed1 = findViewById(R.id.txtone);
        EditText ed2 = findViewById(R.id.txttwo);
        EditText ed3 = findViewById(R.id.txtthree);
        EditText ed4 = findViewById(R.id.txtfour);
        EditText ed5 = findViewById(R.id.txtfive);
        if (ed1.length() == 0) {
            ed1.setText(year + "-" + month + "-" + day + " " + calpower);
        } else if (ed2.length() == 0) {
            ed2.setText(year + "-" + month + "-" + day + " " + calpower);
        } else if (ed3.length() == 0) {
            ed3.setText(year + "-" + month + "-" + day + " " + calpower);
        } else if (ed4.length() == 0) {
            ed4.setText(year + "-" + month + "-" + day + " " + calpower);
        } else if (ed5.length() == 0) {
            ed5.setText(year + "-" + month + "-" + day + " " + calpower);
        }
    }

    public void GetDeleteId()
    {
        int i=0;
        EditText ed1 = findViewById(R.id.txtone);
        EditText ed2 = findViewById(R.id.txttwo);
        EditText ed3 = findViewById(R.id.txtthree);
        EditText ed4 = findViewById(R.id.txtfour);
        EditText ed5 = findViewById(R.id.txtfive);
        if(!ed1.equals(""))
        {
            i=1;
        }else if(!ed2.equals("")){
            i=2;
        }else if(!ed3.equals("")){
            i=3;
        }else if(!ed4.equals("")){
            i=4;
        }else if(!ed5.equals("")){
            i=5;
        }
        db = Main3Activity.getDB();
        Cursor cursor = db.query("Powerthree",null,null,null,null,null,null);
        cursor.moveToFirst();
        if(i!=0) {
            for (int j = 1; j <= i; j++) {
                if (i == j) {
                    int getDeleteId = cursor.getInt(0);
                    deleteDate(getDeleteId);
                }
                cursor.moveToNext();
            }
        }
    }

}
