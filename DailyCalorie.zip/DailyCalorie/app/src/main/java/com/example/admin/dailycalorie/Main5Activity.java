package com.example.admin.dailycalorie;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;

public class Main5Activity extends AppCompatActivity {

    private int daytwo,monthtwo,yeartwo;
    String day,month,year;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main5);

        Button cancel = (Button)findViewById(R.id.cancelbtnthree);
        Button ok = (Button)findViewById(R.id.okbtnthree);

        cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        ok.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DatePicker dp =  findViewById(R.id.datetwo);
                daytwo = dp.getDayOfMonth();
                monthtwo = dp.getMonth();
                yeartwo = dp.getYear();
                Intent intents = getIntent();
                day = intents.getStringExtra("day");
                month = intents.getStringExtra("month");
                year = intents.getStringExtra("year");
                Intent intent = new Intent(Main5Activity.this,MainActivity.class);
                intent.putExtra("yeartwo",Integer.toString(yeartwo));
                intent.putExtra("monthtwo",Integer.toString(monthtwo));
                intent.putExtra("daytwo",Integer.toString(daytwo));
                intent.putExtra("day",day);
                intent.putExtra("month",month);
                intent.putExtra("year",year);
                startActivity(intent);
            }
        });
    }
}
