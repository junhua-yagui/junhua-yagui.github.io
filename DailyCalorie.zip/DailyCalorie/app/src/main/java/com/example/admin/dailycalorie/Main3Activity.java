package com.example.admin.dailycalorie;

import android.content.ContentValues;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;

import org.w3c.dom.Text;

import javax.security.auth.Destroyable;


public class Main3Activity extends AppCompatActivity {

    private static MyDatabaseHelper dbHelper;
    private int day,month,year;
    private String powertxt;
    SQLiteDatabase db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);

       dbHelper = new MyDatabaseHelper(this,6);

        Button yesbtn = (Button)findViewById(R.id.yes);
        yesbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getDate();
                Initiate();//create database
                InsertDate();//insert data
                finish();
            }
        });
    }

    public void getDate()
    {
        DatePicker dp = findViewById(R.id.date);
        day = dp.getDayOfMonth();
        month = dp.getMonth();
        year = dp.getYear();
        EditText et = findViewById(R.id.edittxt);
        powertxt = et.getText().toString();
        if(et==null)
        {
            powertxt = "";
        }
    }

    public void Initiate()
    {
        dbHelper.getWritableDatabase();
    }

    public void InsertDate()
    {
        SQLiteDatabase db = getDB();
        ContentValues values = new ContentValues();
        values.put("year",year);
        values.put("month",month);
        values.put("day",day);
        values.put("power",powertxt);
        db.insert("Powerthree",null,values);
    }

    public static SQLiteDatabase getDB() {
        return dbHelper.getWritableDatabase();
    }

}
