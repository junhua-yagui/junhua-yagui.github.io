package com.example.admin.uifour;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.widget.ImageView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.LinearLayout;

public class MainActivity extends AppCompatActivity {

    private int width=0;
    private  int height=0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        SeekBar sbone = findViewById(R.id.sbSizeone);
        sbone.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                width=progress+100;
                height=progress+100;
                ImageView iv = findViewById(R.id.imageview3);
                iv.setLayoutParams(new LinearLayout.LayoutParams(width, height));
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });

        SeekBar sbtwo = findViewById(R.id.sbSizetwo);
        sbtwo.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                Bitmap bitmap=BitmapFactory.decodeResource(getResources(), R.drawable.m3);
                ImageView iv2 = findViewById(R.id.imageview4);
                Matrix matrix=new Matrix();
                //设置旋转角度
                matrix.setRotate(progress,30,60);
                //通过待旋转的图片和角度生成新的图片
                bitmap=Bitmap.createBitmap(bitmap,0,0,bitmap.getWidth(),bitmap.getHeight(),matrix,true);
                //绑定图片到控件上
                iv2.setImageBitmap(bitmap);
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });

    }


}
