package xzy.myrecoder.View;

import android.Manifest;
import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.StrictMode;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.Fragment;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import xzy.GreebDao.RecoderItemDao;
import xzy.myrecoder.Fragment.PlayFragment;
import xzy.myrecoder.Model.RecoderItem;
import xzy.myrecoder.R;
import xzy.myrecoder.Tool.FileTool;
import xzy.myrecoder.DaoHelper.GreenDaoHelper;
import xzy.myrecoder.Tool.MediaPlayerTool;
import xzy.myrecoder.Tool.RecoderTool;
import xzy.myrecoder.Tool.TimeTool;

public class MainActivity extends AppCompatActivity {


    private Button playBtn;
    private Button stopInterimBtn;
    private Button stopBtn;
    private Button fileBtn;
    private RecoderItemDao recoderItemDao = GreenDaoHelper.getDaoSession().getRecoderItemDao();
    private TimeTool timeTool = new TimeTool();
    private FileTool fileTool = new FileTool();
    private RecoderTool recoderTool = new RecoderTool();

    @Override
    protected void onCreate(final Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        init();


        playBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                playBtn.setVisibility(View.INVISIBLE);
                stopInterimBtn.setVisibility(View.VISIBLE);
                stopBtn.setEnabled(true);
                stopBtn.setAlpha((float) 1);

                recoderTool.startRecord();
            }
        });

        stopInterimBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                playBtn.setVisibility(View.VISIBLE);
                stopInterimBtn.setVisibility(View.INVISIBLE);

                recoderTool.pauseRecord();
            }
        });

        stopBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int num = recoderItemDao.loadAll().size() + 1;//数据库从0开始
                final String itemname = "unnamed" + num + ".amr";
                recoderTool.stopRecord();

                AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
                builder.setCancelable(false);
                builder.setTitle("是否保存？");
                builder.setPositiveButton("保存", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        playBtn.setVisibility(View.VISIBLE);
                        stopInterimBtn.setVisibility(View.INVISIBLE);

                        //将录音完的文件信息放入数据库

                        String date = timeTool.getDate();
                        String size = fileTool.getFileSize(itemname);
                        String length = MediaPlayerTool.getFileLength(itemname);
                        RecoderItem recoderItem = new RecoderItem(null, itemname, size, length, date, false);
                        recoderItemDao.insert(recoderItem);

                    }
                });
                builder.setNegativeButton("删除", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        playBtn.setVisibility(View.VISIBLE);
                        stopInterimBtn.setVisibility(View.INVISIBLE);

                        fileTool.deleteFile(itemname);
                    }
                });
                builder.create().show();


                stopBtn.setAlpha((float) 0.5);
                stopBtn.setEnabled(false);
            }
        });

        fileBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, ItemListView.class);
                startActivity(intent);
            }
        });

    }

    public void init() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            StrictMode.VmPolicy.Builder builder = new StrictMode.VmPolicy.Builder();
            StrictMode.setVmPolicy(builder.build());
        }
        applypermission();
        new FileTool().createFile();

        //set stop and stopInterim Button
        stopInterimBtn = findViewById(R.id.stopInterimbtn);
        stopBtn = findViewById(R.id.stopbtn);
        playBtn = findViewById(R.id.playbtn);
        fileBtn = findViewById(R.id.filebtn);

        stopBtn.setEnabled(false);
        stopBtn.setAlpha((float) 0.5);
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        super.onOptionsItemSelected(item);
        if (item.getItemId() == R.id.about) {
            Intent intent = new Intent(MainActivity.this, AboutActivity.class);
            startActivity(intent);
        }
        return true;
    }

    String[] allpermissions = new String[]{Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.RECORD_AUDIO};

    public void applypermission() {
        if (Build.VERSION.SDK_INT >= 23) {
            boolean needapply = false;
            for (int i = 0; i < allpermissions.length; i++) {
                int chechpermission = ContextCompat.checkSelfPermission(getApplicationContext(), allpermissions[i]);
                if (chechpermission != PackageManager.PERMISSION_GRANTED) {
                    needapply = true;
                }
            }
            if (needapply) {
                ActivityCompat.requestPermissions(MainActivity.this, allpermissions, 1);
            }
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        for (int i = 0; i < grantResults.length; i++) {
            if (grantResults[i] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(MainActivity.this, permissions[i] + "已授权", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(MainActivity.this, permissions[i] + "拒绝授权", Toast.LENGTH_SHORT).show();
            }
        }
    }

    public void creatIntemActivity()
    {
        Intent intent = new Intent(MainActivity.this, ItemListView.class);
        startActivity(intent);
    }
    
}



