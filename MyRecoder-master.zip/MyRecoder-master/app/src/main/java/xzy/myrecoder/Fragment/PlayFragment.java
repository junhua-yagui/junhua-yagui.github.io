package xzy.myrecoder.Fragment;

import android.annotation.SuppressLint;
import android.app.Dialog;
import android.content.Intent;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.Message;
import android.support.v4.app.DialogFragment;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.PopupMenu;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import android.os.Handler;

import java.util.concurrent.TimeUnit;

import xzy.myrecoder.R;
import xzy.myrecoder.Tool.MediaPlayerTool;
import xzy.myrecoder.View.ItemListView;
import xzy.myrecoder.View.MainActivity;


public class PlayFragment extends DialogFragment{
    private Button mediaplayer_moreBtn;
    private Button mediaplayer_playBtn;
    private Button mediaplayer_stopInterimBtn;
    private SeekBar seekBar;
    private TextView fileLengthTextView;
    private TextView currentTimeTextView;
    private MediaPlayer mediaPlayer = new MediaPlayer();

    private Handler handler ;
    private Thread thread;
    //记录播放位置
    private int time;
    //记录是否暂停
    private boolean flage = false;
    //记录进度条是否被拖拽
    private boolean isChanging = false;
    //stores minutes and seconds of the length of the file.
    long minutes = 0;
    long seconds = 0;
    SeekBarThread seekBarThread = new SeekBarThread();
    private String itemname;


    public PlayFragment() {
        // Required empty public constructor
    }


    public void getMediaDuration()
    {
        minutes = TimeUnit.MILLISECONDS.toMinutes(mediaPlayer.getDuration());
        seconds = TimeUnit.MILLISECONDS.toSeconds(mediaPlayer.getDuration())
                - TimeUnit.MINUTES.toSeconds(minutes);
        fileLengthTextView.setText(String.format("%02d:%02d", minutes,Math.abs(seconds-1)));
    }

    @Override
    public View onCreateView(LayoutInflater inflater, final ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_play, container, false);

        Bundle bundle = getArguments();
        itemname = bundle.getString("itemname");

        //分享
        mediaplayer_moreBtn = (Button) view.findViewById(R.id.mediaplayer_more);
        mediaplayer_moreBtn.setOnClickListener(
                new View.OnClickListener() {
                    @SuppressLint("RestrictedApi")
                    @Override
                    public void onClick(View v) {

                        PopupMenu pMenu = new PopupMenu(getActivity(), v);
                        //设置PopupMenu对象的布局
                        pMenu.getMenuInflater().inflate(R.menu.mediaplayer_menu_item, pMenu.getMenu());
                        //设置pMenu菜单的单击监听事件
                        pMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
                            @Override
                            public boolean onMenuItemClick(MenuItem item) {
                                //当点击时弹出被点击象标题
                                Toast.makeText(getActivity(), item.getTitle(), Toast.LENGTH_LONG).show();
                                //MeidaPlayer_fragment.this.dismiss();
                                return true;
                            }
                        });
                        pMenu.show();

                    }
                }
        );

        //播放
        currentTimeTextView = (TextView) view.findViewById(R.id.currentTimeTextView);
        fileLengthTextView = (TextView) view.findViewById(R.id.fileLengthTextView);
        seekBar = (SeekBar) view.findViewById(R.id.seekbar);
        mediaplayer_playBtn = (Button) view.findViewById(R.id.mediaplayer_playBtn);
        mediaplayer_stopInterimBtn = (Button) view.findViewById(R.id.mediaplayer_stopInterimBtn);

        //设置进度时间文字
        handler = new Handler()
        {
            @Override
            public void handleMessage(Message msg){
                super.handleMessage(msg);
                switch (msg.arg1)
                {
                    case 10:
                        long minutes = TimeUnit.MILLISECONDS.toMinutes(mediaPlayer.getCurrentPosition());
                        long seconds = TimeUnit.MILLISECONDS.toSeconds(mediaPlayer.getCurrentPosition())
                                - TimeUnit.MINUTES.toSeconds(minutes);
                        currentTimeTextView.setText(String.format("%02d:%02d", minutes,seconds));
                        break;
                }
            }
        };

        final MediaPlayerTool mediaPlayerTool = new MediaPlayerTool();
        mediaPlayerTool.initMediaPlayer(mediaPlayer,itemname);
        getMediaDuration();//设置音乐长度
        seekBar.setMax(mediaPlayer.getDuration());//设置SeekBar的总长度

        mediaplayer_playBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mediaplayer_playBtn.setVisibility(View.INVISIBLE);
                mediaplayer_stopInterimBtn.setVisibility(View.VISIBLE);
                if (!mediaPlayer.isPlaying()) {
                    mediaPlayer.start();
                    //如果暂停
                    if (flage) {
                        mediaPlayer.seekTo(time);
                        flage=false;
                    }
                    thread = new Thread(seekBarThread);
                    // 启动线程
                    thread.start();
                }
                //暂停
                mediaplayer_stopInterimBtn.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (mediaPlayer.isPlaying())
                            mediaPlayer.pause();
                        mediaplayer_playBtn.setVisibility(View.VISIBLE);
                        mediaplayer_stopInterimBtn.setVisibility(View.INVISIBLE);
                        time = mediaPlayer.getCurrentPosition();
                        flage = true;
                    }
                });
            }
        });
        //拖拽seekbar检测
        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
                isChanging = true;
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                mediaPlayer.seekTo(seekBar.getProgress());
                isChanging = false;
            }
        });

        //播放结束
        mediaPlayer.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                mediaplayer_playBtn.setVisibility(View.VISIBLE);
                mediaplayer_stopInterimBtn.setVisibility(View.INVISIBLE);
                mediaPlayer.reset();
                seekBar.setProgress(0);
                currentTimeTextView.setText(String.format("%02d:%02d", 0,0));
            }
        });

        //返回键监听
        view.setFocusable(true);//这个和下面的这个命令必须要设置了，才能监听back事件。
        view.setFocusableInTouchMode(true);
        view.setOnKeyListener(backlistener);
        return view;
    }

    @Override
    public void onStart() {
        super.onStart();
        //改变dialogfragment 宽度占比
        Dialog dialog = getDialog();
        if (dialog != null) {
            DisplayMetrics dm = new DisplayMetrics();
            getActivity().getWindowManager().getDefaultDisplay().getMetrics(dm);
            dialog.getWindow().setLayout((int) (dm.widthPixels * 0.95), ViewGroup.LayoutParams.WRAP_CONTENT);
        }

        dialog.setCanceledOnTouchOutside(false);
    }

    public void exit()
    {
        if(mediaPlayer!=null) {
            mediaPlayer.stop();
            mediaPlayer.release();
        }
    }


    // 自定义的线程
    class  SeekBarThread  implements Runnable {
        @Override
        public void run() {
            while (!isChanging && mediaPlayer.isPlaying()) {
                // 将SeekBar位置设置到当前播放位置
                seekBar.setProgress(mediaPlayer.getCurrentPosition());
                Message message = new Message();
                message.arg1=10;
                handler.sendMessage(message);
                try {
                    // 每100毫秒更新一次位置
                    Thread.sleep(1000);
                    //播放进度
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }
    };

    private View.OnKeyListener backlistener = new View.OnKeyListener() {
        @Override
        public boolean onKey(View view, int i, KeyEvent keyEvent) {
            if (keyEvent.getAction() == KeyEvent.ACTION_DOWN) {
                if (i == KeyEvent.KEYCODE_BACK) {  //表示按返回键 时的操作
                        if(mediaPlayer!=null) {
                            mediaPlayer.stop();
                            getActivity().finish();
                            Intent intent = new Intent(getContext(), ItemListView.class);
                            startActivity(intent);
                             }
                            Log.d("ahaha","haha");
                        return true;
                    } //后退
                    return false;    //已处理
                }
            return false;
        }
    };

}
