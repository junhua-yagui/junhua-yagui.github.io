package xzy.myrecoder.Tool;

import android.os.Environment;
import android.util.Log;

import java.io.File;

public class FileTool {
    public final String path = Environment.getExternalStorageDirectory().getAbsolutePath() + "/recoreder_res";

    public void createFile() {
        File file = new File(path);
        if (!file.exists()) {
            file.mkdirs();
            //两种方式判断文件夹是否创建成功
            //Folder.isDirectory()返回True表示文件路径是对的，即文件创建成功，false则相反
            boolean isFilemaked1 = file.isDirectory();
            //Folder.mkdirs()返回true即文件创建成功，false则相反
            boolean isFilemaked2 = file.mkdirs();

            if (isFilemaked1 || isFilemaked2) {
                Log.i("share", "创建文件夹成功");
            } else {
                Log.i("share", "创建文件夹失败");
            }

        } else {
            Log.i("share", "文件夹已存在");
        }

    }

    public String getFileSize(String fileName)
    {
        File file = new File(path+"/"+fileName);
        if (file.exists() && file.isFile()) {
            return (file.length()/1024)+"KB";
        }
        return "null";
    }

    public void deleteFile(String fileName){
        File file = new File(path+"/"+fileName);
        if (file.exists() && file.isFile()) {
            file.delete();
        }
    }

    public void renameFile(String oldName,String newName)
    {
        File oldfile = new File(path+"/"+oldName);
        File newfile = new File(path+"/"+newName);
        if (oldfile.exists() && oldfile.isFile()) {
            oldfile.renameTo(newfile);
        }
    }
}
