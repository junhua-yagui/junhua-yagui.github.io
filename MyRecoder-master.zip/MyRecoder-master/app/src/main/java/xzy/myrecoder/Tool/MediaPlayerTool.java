package xzy.myrecoder.Tool;

import android.media.MediaPlayer;
import android.os.Environment;

import android.support.v7.app.AppCompatActivity;
import android.util.Log;


import java.io.File;
import java.io.IOException;
import java.util.concurrent.TimeUnit;


public class MediaPlayerTool {

    public final static String path = Environment.getExternalStorageDirectory().getAbsolutePath() + "/recoreder_res";
    public  void initMediaPlayer(MediaPlayer mediaPlayer,String itemname)
    {
        try{
            mediaPlayer.setDataSource(path+"/"+itemname);
            mediaPlayer.prepare();
        }catch (Exception e)
        {
            e.printStackTrace();
        }
    }

    public static String getFileLength(String fileName)
    {
        MediaPlayer mediaPlayer = new MediaPlayer();
        long minutes = 0;
        long seconds = 0;
        try {
            mediaPlayer.setDataSource(path+"/"+fileName);
            mediaPlayer.prepare();
        } catch (IOException e) {
            e.printStackTrace();

        }
        minutes = TimeUnit.MILLISECONDS.toMinutes(mediaPlayer.getDuration());
        seconds = TimeUnit.MILLISECONDS.toSeconds(mediaPlayer.getDuration())
                - TimeUnit.MINUTES.toSeconds(minutes);
        return String.format("%02d:%02d", minutes,Math.abs(seconds-1));
    }
}
