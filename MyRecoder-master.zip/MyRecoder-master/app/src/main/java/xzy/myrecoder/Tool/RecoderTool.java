package xzy.myrecoder.Tool;

import android.media.AudioFormat;
import android.media.AudioRecord;
import android.media.MediaRecorder;
import android.os.Environment;
import android.widget.Toast;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.sql.Time;
import java.util.ArrayList;

import xzy.GreebDao.RecoderItemDao;
import xzy.myrecoder.DaoHelper.GreenDaoHelper;
import xzy.myrecoder.View.MainActivity;

public class RecoderTool
{
    private final String path = Environment.getExternalStorageDirectory().getAbsolutePath() + "/recoreder_res";
    private TimeTool timeTool = new TimeTool();
    private MediaRecorder mRecorder;// 录音器
    private boolean isPause = false;//暂停状态
    private String fileName = null;
    private ArrayList<String> mList = new ArrayList<String>();// 待合成的录音片段
    private RecoderItemDao recoderItemDao= GreenDaoHelper.getDaoSession().getRecoderItemDao();


    public void startRecord() {

        mRecorder = new MediaRecorder();
        if (!isPause) {
            // 新录音清空列表
            mList.clear();
        }

        fileName = path + "/" + timeTool.getDate()+"_"+timeTool.getTime() + ".amr";
        mRecorder.setAudioSource(MediaRecorder.AudioSource.MIC);
        // 选择amr格式
        mRecorder.setOutputFormat(MediaRecorder.OutputFormat.RAW_AMR);
        mRecorder.setOutputFile(fileName);
        mRecorder.setAudioEncoder(MediaRecorder.AudioEncoder.AMR_NB);
        try {
            mRecorder.prepare();
        } catch (Exception e) {
        }
        if (mRecorder != null) {
            mRecorder.start();
        }

    }

    public void pauseRecord(){
        mRecorder.stop();
        mRecorder.release();

        // 将录音片段加入列表
        mList.add(fileName);
        isPause = true;
    }


    public void stopRecord() {
        if(isPause==false)
        mList.add(fileName);

        mRecorder.release();
        mRecorder = null;
        isPause = false;
         int num = recoderItemDao.loadAll().size();
        // 最后合成的音频文件
        fileName = path + "/" + "unnamed"+(num+1)+".amr";
        FileOutputStream fileOutputStream = null;
        try {
            fileOutputStream = new FileOutputStream(fileName);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        FileInputStream fileInputStream = null;
        try {
            for (int i = 0; i < mList.size(); i++) {
                File file = new File(mList.get(i));
                // 把因为暂停所录出的多段录音进行读取
                fileInputStream = new FileInputStream(file);
                byte[] mByte = new byte[fileInputStream.available()];
                int length = mByte.length;
                // 第一个录音文件的前六位是不需要删除的
                if (i == 0) {
                    while (fileInputStream.read(mByte) != -1) {
                        fileOutputStream.write(mByte, 0, length);
                    }
                }
                // 之后的文件，去掉前六位
                else {
                    while (fileInputStream.read(mByte) != -1) {

                        fileOutputStream.write(mByte, 6, length - 6);
                    }
                }
            }

        } catch (Exception e) {
            // 这里捕获流的IO异常，万一系统错误需要提示用户
            e.printStackTrace();
        } finally {
            try {
                fileOutputStream.flush();
                fileInputStream.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        // 不管合成是否成功、删除录音片段
        for (int i = 0; i < mList.size(); i++) {
            File file = new File(mList.get(i));
            if (file.exists()) {
                file.delete();
            }
        }

    }

}
